package guiapp;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class showuserinfo extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
    private JTable table;
    private JTextField usernameField;
    private JPasswordField passwordField; // Use JPasswordField for password input
    private JButton loginButton;
    private JLabel lblNewLabel;
    private JLabel lblNewLabel_1;

    // Database connection
    private Connection connection;
    private JPanel panel;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    showuserinfo frame = new showuserinfo();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public showuserinfo() {
        setResizable(false);
        setForeground(Color.WHITE);
        setBackground(Color.WHITE);
        setTitle("User Information");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 810, 506);
        contentPane = new JPanel();
        contentPane.setBackground(Color.WHITE);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(0, 98, 796, 361);
        contentPane.add(scrollPane);

        table = new JTable();
        scrollPane.setViewportView(table);

        usernameField = new JTextField();
        usernameField.setBounds(83, 26, 96, 42);
        contentPane.add(usernameField);
        usernameField.setColumns(10);

        passwordField = new JPasswordField(); // Use JPasswordField for password input
        passwordField.setBounds(395, 26, 96, 42);
        contentPane.add(passwordField);
        passwordField.setColumns(10);

        loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Call method to authenticate user
                authenticateUser();
            }
        });
        loginButton.setBounds(660, 47, 85, 21);
        contentPane.add(loginButton);

        lblNewLabel = new JLabel("Username:");
        lblNewLabel.setForeground(SystemColor.controlLtHighlight);
        lblNewLabel.setBounds(10, 29, 73, 39);
        contentPane.add(lblNewLabel);

        lblNewLabel_1 = new JLabel("Password:");
        lblNewLabel_1.setForeground(SystemColor.text);
        lblNewLabel_1.setBounds(323, 29, 62, 39);
        contentPane.add(lblNewLabel_1);
        
        JButton btnNewButton = new JButton(">");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		new user().setVisible(true); 
        	}
        });
        btnNewButton.setBounds(0, -2, 62, 21);
        contentPane.add(btnNewButton);
        
        panel = new JPanel();
        panel.setBackground(SystemColor.textHighlight);
        panel.setBounds(0, 10, 796, 101);
        contentPane.add(panel);

        // Connect to the database
        connectToDatabase();
    }

    // Method to authenticate user against database
 // Method to authenticate user against database
    private void authenticateUser() {
        try {
            // Get username and password from text fields
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword()).trim(); // Retrieve password securely

            // Prepare SQL statement to select user information based on username and password
            String query = "SELECT * FROM user WHERE username = ? AND password = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);

            // Execute the query
            ResultSet resultSet = statement.executeQuery();

            // Create a table model to hold the user information
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("username");
            model.addColumn("password");

            // Iterate through the ResultSet to add all matching rows to the table model
            while (resultSet.next()) {
                // Retrieve user information from the current row and add it to the table model
                String dbUsername = resultSet.getString("jobtitle");
                String dbPassword = resultSet.getString("skills");
                model.addRow(new Object[]{dbUsername, dbPassword});
            }

            // Set the table model
            table.setModel(model);

            // If no matching user found, display an error message
            if (model.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "Invalid username or password", "Error", JOptionPane.ERROR_MESSAGE);
            }

            // Close ResultSet and PreparedStatement
            resultSet.close();
            statement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to connect to the database
    private void connectToDatabase() {
    	 try {
    	        // Load database driver
    	        Class.forName("com.mysql.jdbc.Driver");

    	        // Connect to the database
    	        String url = "jdbc:mysql://localhost:3306/student"; // Update with your database URL
    	        String username = "root"; // Update with your database username
    	        String password = ""; // Update with your database password
    	        connection = DriverManager.getConnection(url, username, password);
    	        System.out.println("Connected to the database.");
    	    } catch (ClassNotFoundException | SQLException ex) {
    	        ex.printStackTrace();
    	        JOptionPane.showMessageDialog(this, "Database connection error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    	    }
    	}
}

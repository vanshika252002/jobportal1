package guiapp;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.SystemColor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class recruiter extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private Connection connection;
	private JTable t1;
	private JTextField l1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					recruiter frame = new recruiter();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public recruiter() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 833, 607);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.text);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.textHighlight);
		panel.setBounds(0, 0, 819, 124);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome Recruiter");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel.setForeground(SystemColor.text);
		lblNewLabel.setBackground(new Color(240, 240, 240));
		lblNewLabel.setBounds(263, 10, 311, 104);
		panel.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 158, 819, 412);
		contentPane.add(scrollPane);
		
		t1 = new JTable();
		scrollPane.setViewportView(t1);
		
		l1 = new JTextField();
		l1.setBounds(335, 129, 96, 19);
		contentPane.add(l1);
		l1.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("jobtitle");
		lblNewLabel_1.setBounds(107, 129, 96, 19);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String jobTitle = l1.getText().trim();

                // Fetch and display user details with the entered job title
                fetchAndDisplayUserDetails(jobTitle);
                
                // Disable the submit button after it is clicked
                
			}
		});
		btnNewButton.setBounds(603, 128, 85, 21);
		contentPane.add(btnNewButton);

        
        // Connect to the database
        connectToDatabase();

        // Fetch and display user details with the same job title
        //fetchAndDisplayUserDetails();
    }

    // Method to connect to the database
    private void connectToDatabase() {
        try {
            // Load database driver
            Class.forName("com.mysql.jdbc.Driver");

            // Connect to the database
            String url = "jdbc:mysql://localhost:3306/student"; // Update with your database URL
            String username = "root"; // Update with your database username
            String password = ""; // Update with your database password
             connection = DriverManager.getConnection(url, username, password);
            System.out.println("Connected to the database.");
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
            // Handle database connection error
        }
    }

    // Method to fetch and display user details with the same job title
 // Method to fetch and display user details with the same job title
   
        
    
 // Method to fetch and display user details with the provided job title
    private void fetchAndDisplayUserDetails(String jobTitle) {
        try {
            // Prepare SQL statement to select user details based on job title
            String query = "SELECT * FROM user WHERE jobtitle = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, jobTitle);

            // Execute the query
            ResultSet resultSet = statement.executeQuery();
            if (!resultSet.isBeforeFirst()) {
                // If ResultSet is empty, display an error message
                JOptionPane.showMessageDialog(this, "No matching records found for the entered job title.", "Error", JOptionPane.ERROR_MESSAGE);
                return; // Exit the method
            }


            // Create a table model to hold the user details
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("name");
            model.addColumn("skills");
            // Add additional columns as needed

            // Iterate through the ResultSet to add user details to the table model
            while (resultSet.next()) {
                // Retrieve user details from the current row and add them to the table model
                String username = resultSet.getString("name");
                String password = resultSet.getString("skills");
                // Add additional details to the table model as needed
                model.addRow(new Object[] { username, password });
            }

            // Set the table model to the JTable
            t1.setModel(model);

            // Close ResultSet and PreparedStatement
            resultSet.close();
            statement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            // Handle SQL exception
        }
    }
}
package guiapp;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

import java.awt.Color;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.SystemColor;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class adminseeuser extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tblData;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					adminseeuser frame = new adminseeuser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public adminseeuser() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 834, 598);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 115, 820, 436);
		contentPane.add(scrollPane);
		
		tblData = new JTable();
		scrollPane.setViewportView(tblData);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.textHighlight);
		panel.setBounds(0, -11, 820, 123);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Users Enrolled");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblNewLabel.setForeground(SystemColor.text);
		lblNewLabel.setBounds(260, 27, 375, 69);
		panel.add(lblNewLabel);
		
		JButton btnNewButton = new JButton(">");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new admin().setVisible(true); 
				
			}
		});
		btnNewButton.setBounds(0, 10, 61, 32);
		panel.add(btnNewButton);
		
		 

// Fetch data from the database when the window frame opens
fetchDataFromDatabase();
}
		

private void fetchDataFromDatabase() 
{
    
 	 try {
 	        Class.forName("com.mysql.jdbc.Driver");
 	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "");
 	        System.out.println("connected");

 	        java.sql.Statement st = con.createStatement();
 	        ResultSet rs = st.executeQuery("select jobtitle,name,role,experience ,skills,salaryexpectation,education from  user");

 	        DefaultTableModel model = new DefaultTableModel();
 	        tblData.setModel(model);

 	        // Add columns to the table model
 	        ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();
 	        int columnCount = metaData.getColumnCount();
 	        for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++)
 	        {
 	            model.addColumn(metaData.getColumnLabel(columnIndex));
 	        }

 	        // Add rows to the table model
 	        while (rs.next())
 	        {
 	        Object[] rowData = new Object[columnCount];
 	        for (int i = 0; i < columnCount; i++) {
 	        rowData[i] = rs.getObject(i + 1);
 	        }
 	        model.addRow(rowData);
 	        }

 	        st.close();
 	        con.close(); } catch (ClassNotFoundException | SQLException e1) {
 	        e1.printStackTrace();
 	    }
 }
}


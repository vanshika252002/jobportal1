package guiapp;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class afterapplybutton extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField l1;
	private JTextField l2;
	private JTextField l3;
	private JTextField l4;
	private JTextField l5;
	private JTextField l6;
	private JTextField l7;
	private JTextField l8;
	private JTextField l20;
	private JTextField l30;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					afterapplybutton frame = new afterapplybutton();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public afterapplybutton() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 763, 552);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("name");
		lblNewLabel.setBounds(104, 71, 78, 22);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("role");
		lblNewLabel_1.setBounds(104, 115, 45, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("experience");
		lblNewLabel_2.setBounds(104, 164, 99, 13);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("skills");
		lblNewLabel_3.setBounds(104, 212, 99, 22);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("salary expectation");
		lblNewLabel_4.setBounds(104, 266, 84, 22);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("education");
		lblNewLabel_5.setBounds(104, 321, 99, 34);
		contentPane.add(lblNewLabel_5);
		
		l1 = new JTextField();
		l1.setBounds(219, 73, 96, 19);
		contentPane.add(l1);
		l1.setColumns(10);
		
		l2 = new JTextField();
		l2.setBounds(219, 112, 96, 19);
		contentPane.add(l2);
		l2.setColumns(10);
		
		l3 = new JTextField();
		l3.setBounds(219, 158, 96, 19);
		contentPane.add(l3);
		l3.setColumns(10);
		
		l4 = new JTextField();
		l4.setBounds(219, 214, 96, 19);
		contentPane.add(l4);
		l4.setColumns(10);
		
		l5 = new JTextField();
		l5.setBounds(219, 268, 96, 19);
		contentPane.add(l5);
		l5.setColumns(10);
		
		l6 = new JTextField();
		l6.setBounds(219, 329, 96, 19);
		contentPane.add(l6);
		l6.setColumns(10);
		
		
		//start
		
		
		
		
		
		JButton btnNewButton = new JButton("submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name=l1.getText();
				String role=l2.getText();
				String experience=l3.getText();
				String skills=l4.getText();
				String salaryexpectation=l5.getText();
				String education=l6.getText();
				String jobtitle=l8.getText();
				String username=l20.getText();
				String password=l30.getText();
				
				
				
				
				
				if (name.isEmpty() || role.isEmpty() || experience.isEmpty() || skills.isEmpty() || 
			            salaryexpectation.isEmpty() || education.isEmpty() || jobtitle.isEmpty()) {
			            JOptionPane.showMessageDialog(null, "Please enter all details", "Incomplete Details", JOptionPane.WARNING_MESSAGE);
			            return; // Exit the method without further execution
			        }
				
				
				
				
				boolean submissionMade=false;
				if (submissionMade) {
		            JOptionPane.showMessageDialog(null, "You have already submitted your details", "Already Submitted", JOptionPane.INFORMATION_MESSAGE);
		            return; // Exit the method without further execution
		        }
		        
		        // Set the submissionMade flag to true and disable the submit button
		        submissionMade = true;
		        btnNewButton.setEnabled(false);

			        
			
				
				
				//start
				
				try {
					
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
						PreparedStatement stmt = null;
						System.out.print("connected");
					//	java.sql.Statement stmt=con.createStatement();  
						//ResultSet rs=stmt.executeQuery("select * from login");  
						String sql = "INSERT INTO user(username,password,jobtitle,name, role,experience,skills,salaryexpectation,education) VALUES (?,?,?,?,?,?,?,?,?)";
						 stmt = con.prepareStatement(sql);

				            // Set parameters
						    stmt.setString(1,username);
						    stmt.setString(2,password);
						    stmt.setString(3,jobtitle);
				            stmt.setString(4, name);
				            stmt.setString(5, role);
				            stmt.setString(6,experience);
				            stmt.setString(7,skills);
				            stmt.setString(8,salaryexpectation);
				            stmt.setString(9,education);
				           
				            
				           
				            stmt.executeUpdate();
				            System.out.println("Data inserted successfully.");
				         // Inside the try block where data insertion is successful
				            JOptionPane.showMessageDialog(null, "Submission Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
				            dispose();
						
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} 
				
				//end
				
				//System.out.println("  "+name+"  "+mailid+"  "+mobileno+"  "+qualification+"  "+role+"  "+education+"  "+password+"  "+confirm);
				
				

			}
				
				
				
				
				
			
		});
		btnNewButton.setBounds(523, 415, 85, 21);
		contentPane.add(btnNewButton);
		
		l7 = new JTextField();
		l7.setBounds(74, 42, 96, 19);
		contentPane.add(l7);
		l7.setColumns(10);
		
		l8 = new JTextField();
		l8.setBounds(219, 42, 433, 19);
		contentPane.add(l8);
		l8.setColumns(10);
		
		l20 = new JTextField();
		l20.setBounds(219, 381, 96, 19);
		contentPane.add(l20);
		l20.setColumns(10);
		
		l30 = new JTextField();
		l30.setBounds(219, 433, 96, 19);
		contentPane.add(l30);
		l30.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("username");
		lblNewLabel_6.setBounds(104, 384, 45, 13);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("password");
		lblNewLabel_7.setBounds(104, 436, 45, 13);
		contentPane.add(lblNewLabel_7);
		
		JButton btnNewButton_1 = new JButton(">");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new applyforajob().setVisible(true); 
			}
		});
		btnNewButton_1.setBounds(0, 0, 45, 28);
		contentPane.add(btnNewButton_1);
	}
		
		
		public void setLabelText(String text) {
			 l7.setText(text);
	        String sno=text;

try {
	
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "");

    // Define the SQL query with a WHERE clause to filter by sno
    String sql = "SELECT jobtitle FROM postajob WHERE sno = ?";
    
    // Prepare the SQL statement
    PreparedStatement stmt = con.prepareStatement(sql);
    
    // Set the snoo value as a parameter in the PreparedStatement
    stmt.setString(1, sno);
    
    // Execute the query
    ResultSet rs = stmt.executeQuery();

    // Check if a matching jobtitle was found
    if (rs.next()) {
        // Retrieve the jobtitle value from the result set
        String jobTitle = rs.getString("jobtitle");
        
        // Set the retrieved jobtitle value to the JTextField l8
        l8.setText(jobTitle);
    } else {
        // If no matching jobtitle was found, display a message
        l8.setText("Job not found for sno: " + sno);
    }

    // Close the result set, statement, and connection
    rs.close();
    stmt.close();
    con.close();
} catch (SQLException ex) {
    // Handle any SQL exceptions
    ex.printStackTrace();
    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}
		
		
		
		
		
		
		
		//end

	        
	        
	}
}


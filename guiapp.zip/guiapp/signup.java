package guiapp;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.ImageIcon;

public class signup extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField l1;
	private JTextField l2;
	private JTextField l3;
	private JTextField l4;
	private JTextField l5;
	private JTextField l7;
	private JTextField l8;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					signup frame = new signup();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public signup() {
		setTitle("SIGNUP");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 826, 457);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Name ");
		lblNewLabel_1.setForeground(new Color(148, 0, 211));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1.setBounds(341, 45, 60, 27);
		contentPane.add(lblNewLabel_1);
		
		
		JLabel lblNewLabel_2 = new JLabel("Mail Id");
		lblNewLabel_2.setForeground(new Color(148, 0, 211));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(341, 82, 60, 34);
		contentPane.add(lblNewLabel_2);
		
		
		l1 = new JTextField();
		l1.setBounds(479, 51, 205, 19);
		contentPane.add(l1);
		l1.setColumns(10);
		
		l2 = new JTextField();
		l2.setBounds(479, 92, 205, 19);
		contentPane.add(l2);
		l2.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Mobile No");
		lblNewLabel_3.setForeground(new Color(148, 0, 211));
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_3.setBounds(338, 126, 92, 27);
		contentPane.add(lblNewLabel_3);
		
		l3 = new JTextField();
		l3.setBounds(479, 132, 205, 19);
		contentPane.add(l3);
		l3.setColumns(10);
		
		
		JLabel lblNewLabel_4 = new JLabel("Qualification");
		lblNewLabel_4.setForeground(new Color(148, 0, 211));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_4.setBounds(338, 176, 117, 27);
		contentPane.add(lblNewLabel_4);
		
		l4 = new JTextField();
		l4.setBounds(479, 182, 207, 19);
		contentPane.add(l4);
		l4.setColumns(10);
		
		
		
		JLabel lblNewLabel_5 = new JLabel("Role");
		lblNewLabel_5.setForeground(new Color(148, 0, 211));
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_5.setBounds(338, 229, 92, 19);
		contentPane.add(lblNewLabel_5);
		
		l5 = new JTextField();
		l5.setBounds(479, 231, 207, 19);
		contentPane.add(l5);
		l5.setColumns(10);
		
		
		
		
		JLabel lblNewLabel_7 = new JLabel("Password");
		lblNewLabel_7.setForeground(new Color(148, 0, 211));
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_7.setBounds(338, 275, 101, 27);
		contentPane.add(lblNewLabel_7);
		
		
		JLabel lblNewLabel_8 = new JLabel("confirm Password");
		lblNewLabel_8.setForeground(new Color(148, 0, 211));
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_8.setBounds(341, 334, 137, 27);
		contentPane.add(lblNewLabel_8);
		
		
		
		l7 = new JTextField();
		l7.setBounds(479, 281, 207, 19);
		contentPane.add(l7);
		l7.setColumns(10);
		
		l8 = new JTextField();
		l8.setBounds(479, 340, 203, 19);
		contentPane.add(l8);
		l8.setColumns(10);
		
		
		JButton btnNewButton = new JButton("<");
		btnNewButton.setBackground(new Color(221, 160, 221));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new app().setVisible(true); 
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(0, 0, 60, 27);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("SUBMIT");
		btnNewButton_1.setBackground(new Color(221, 160, 221));
		btnNewButton_1.setForeground(new Color(148, 0, 211));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/*
				String name=l1.getText();
				String mailid=l2.getText();
				String mobileno=l3.getText();
				String qualification=l4.getText();
				String role=l5.getText();
				String education=l6.getText();
				String password=l7.getText();
				String confirmpassword=l8.getText();
				//start
				
				try {
					
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/student","root","");
						PreparedStatement stmt = null;
						System.out.print("connected");
					//	java.sql.Statement stmt=con.createStatement();  
						//ResultSet rs=stmt.executeQuery("select * from login");  
						String sql = "INSERT INTO signup(name, mailid,mobileno,qualification,role,education,password, confirmpassword) VALUES (?,?,?,?,?,?,?,?)";
						 stmt = con.prepareStatement(sql);

				            // Set parameters
				            stmt.setString(1, name);
				            stmt.setString(2, mailid);
				            stmt.setString(3,mobileno);
				            stmt.setString(4,qualification);
				            stmt.setString(5,role);
				            stmt.setString(6,education);
				            stmt.setString(7,password);
				            stmt.setString(8,confirmpassword);
				           
				            stmt.executeUpdate();
				            System.out.println("Data inserted successfully.");
						
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} 
				
				
				*/
				
				
				
				//start
				String name1=l1.getText();
			
				String password1=l7.getText();
			
				//start
				
				try {
					
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
						PreparedStatement stmt = null;
						System.out.print("connected");
					//	java.sql.Statement stmt=con.createStatement();  
						//ResultSet rs=stmt.executeQuery("select * from login");  
						String sql = "INSERT INTO login(username,password) VALUES (?,?)";
						 stmt = con.prepareStatement(sql);

				            // Set parameters
				            stmt.setString(1, name1);
				           
				            stmt.setString(2,password1);
				         
				           
				            stmt.executeUpdate();
				            System.out.println("Data inserted successfully.");
				            dispose();
						
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} 
				
				
				
				
				//end
				
				//System.out.println("  "+name+"  "+mailid+"  "+mobileno+"  "+qualification+"  "+role+"  "+education+"  "+password+"  "+confirm);
				
				

			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBounds(689, 380, 123, 40);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\vansh\\OneDrive\\Pictures\\Screenshots\\Screenshot (11).png"));
		lblNewLabel.setBounds(0, 0, 328, 420);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_9 = new JLabel("SIGN UP");
		lblNewLabel_9.setForeground(new Color(148, 0, 211));
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_9.setBounds(499, 0, 86, 62);
		contentPane.add(lblNewLabel_9);
	}
}

package guiapp;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class postajob extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField l1;
	private JTextField l2;
	private JTextField l3;
	private JTextField l4;
	private JTextField l5;
	private JTextField l6;
	private JTextField l7;
	private JTextField l8;
	private JTextField l9;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					postajob frame = new postajob();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public postajob() {
		setBackground(SystemColor.inactiveCaptionBorder);
		setTitle("postajob");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 767, 469);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.textHighlight);
		panel.setBounds(0, 0, 764, 50);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_9 = new JLabel("POST A JOB ");
		lblNewLabel_9.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_9.setBackground(Color.WHITE);
		lblNewLabel_9.setBounds(266, 10, 348, 30);
		panel.add(lblNewLabel_9);
		
		JButton btnNewButton_1 = new JButton("<");
		btnNewButton_1.setBackground(SystemColor.textHighlight);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new admin().setVisible(true); 
				
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_1.setBounds(0, 0, 50, 21);
		panel.add(btnNewButton_1);
		
		l1 = new JTextField();
		l1.setBounds(42, 102, 331, 19);
		contentPane.add(l1);
		l1.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Category");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(42, 80, 96, 19);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Job Title*");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(451, 84, 105, 13);
		contentPane.add(lblNewLabel_1);
		
		l2 = new JTextField();
		l2.setBounds(451, 102, 292, 19);
		contentPane.add(l2);
		l2.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Job Type");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(42, 142, 150, 19);
		contentPane.add(lblNewLabel_2);
		
		l3 = new JTextField();
		l3.setBounds(42, 162, 331, 19);
		contentPane.add(l3);
		l3.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Salary Package");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_3.setBounds(451, 141, 159, 19);
		contentPane.add(lblNewLabel_3);
		
		l4 = new JTextField();
		l4.setBounds(451, 162, 292, 19);
		contentPane.add(l4);
		l4.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Skill Required");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_4.setBounds(42, 206, 119, 19);
		contentPane.add(lblNewLabel_4);
		
		l5 = new JTextField();
		l5.setBounds(42, 235, 331, 19);
		contentPane.add(l5);
		l5.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Experience");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_5.setBounds(451, 209, 174, 13);
		contentPane.add(lblNewLabel_5);
		
		l6 = new JTextField();
		l6.setBounds(451, 235, 292, 19);
		contentPane.add(l6);
		l6.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Job Location");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_6.setBounds(42, 276, 131, 19);
		contentPane.add(lblNewLabel_6);
		
		l7 = new JTextField();
		l7.setBounds(42, 300, 331, 19);
		contentPane.add(l7);
		l7.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Job Expiration Date");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_7.setBounds(451, 281, 193, 13);
		contentPane.add(lblNewLabel_7);
		
		l8 = new JTextField();
		l8.setBounds(451, 304, 292, 19);
		contentPane.add(l8);
		l8.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Job Description");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_8.setBounds(42, 329, 234, 13);
		contentPane.add(lblNewLabel_8);
		
		l9 = new JTextField();
		l9.setBounds(42, 352, 701, 41);
		contentPane.add(l9);
		l9.setColumns(10);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String category=l1.getText();
				String jobtitle=l2.getText();
				String jobtype=l3.getText();
				String salarypackage =l4.getText();
				String skillsrequired=l5.getText();
				String experience=l6.getText();
				String joblocation=l7.getText();
				String jobexpirationdate=l8.getText();
				String jobdescription=l9.getText();
				
				try {
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
					PreparedStatement stmt = null;
					System.out.print("connected");
				//	java.sql.Statement stmt=con.createStatement();  
					//ResultSet rs=stmt.executeQuery("select * from login");  
					String sql = "INSERT INTO postajob(category, jobtype,skillsrequired,joblocation,jobdescription,jobtitle,salarypackage, experience,jobexpirationdate) VALUES (?,?,?,?,?,?,?,?,?)";
					 stmt = con.prepareStatement(sql);

			            // Set parameters
			            stmt.setString(1,category);
			            stmt.setString(2,jobtype);
			            stmt.setString(3,skillsrequired);
			            stmt.setString(4,joblocation);
			            stmt.setString(5,jobdescription);
			            stmt.setString(6,jobtitle);
			            stmt.setString(7,salarypackage);
			            stmt.setString(8,experience);
			            stmt.setString(9,jobexpirationdate);
			           
			            stmt.executeUpdate();
			            dispose();
					
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
			
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setBounds(596, 403, 131, 21);
		contentPane.add(btnNewButton);
	}
}

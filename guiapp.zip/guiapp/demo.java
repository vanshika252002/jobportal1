package guiapp;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.SystemColor;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class demo extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable tblData;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    demo frame = new demo();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public demo() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1030, 595);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.text);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
                                                        
                                                                JScrollPane scrollPane = new JScrollPane();
                                                                scrollPane.setBounds(0, 52, 1016, 506);
                                                                contentPane.add(scrollPane);
                                                                
                                                                        tblData = new JTable();
                                                                        scrollPane.setViewportView(tblData);
                                                                        
                                                                                JScrollPane scrollPane_1 = new JScrollPane();
                                                                                scrollPane.setRowHeaderView(scrollPane_1);
                                                                                
                                                                                JPanel panel = new JPanel();
                                                                                panel.setBackground(SystemColor.textHighlight);
                                                                                panel.setBounds(0, 0, 1016, 60);
                                                                                contentPane.add(panel);
                                                                                panel.setLayout(null);
                                                                                
                                                                                JLabel lblNewLabel = new JLabel("JOBS");
                                                                                lblNewLabel.setForeground(SystemColor.text);
                                                                                lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 25));
                                                                                lblNewLabel.setBounds(416, 10, 157, 33);
                                                                                panel.add(lblNewLabel);
                                                                                
                                                                                        JButton btnNewButton = new JButton("");
                                                                                        btnNewButton.setBounds(1024, 1, 7, 42);
                                                                                        panel.add(btnNewButton);
                                                                                        btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
                                                                                        btnNewButton.setBackground(SystemColor.textHighlight);
                                                                                        btnNewButton.setForeground(SystemColor.text);
                                                                                        
                                                                                        JButton btnNewButton_1 = new JButton(">");
                                                                                        btnNewButton_1.addActionListener(new ActionListener() {
                                                                                        	public void actionPerformed(ActionEvent e) {
                                                                                        		new admin().setVisible(true); 
                                                                                        	}
                                                                                        });
                                                                                        btnNewButton_1.setBounds(10, 20, 85, 21);
                                                                                        panel.add(btnNewButton_1);
                                                                                        btnNewButton.addActionListener(e -> fetchDataFromDatabase());

        // Fetch data from the database when the window frame opens
        fetchDataFromDatabase();
    }

    private void fetchDataFromDatabase() {
       /* try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/student", "root", "");
            System.out.println("connected");

            java.sql.Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from login");

            DefaultTableModel model = (DefaultTableModel) tblData.getModel();
            model.setRowCount(0); // Clear existing data
            int cols = rs.getMetaData().getColumnCount();
            while (rs.next()) {
                Object[] row = new Object[cols];
                for (int i = 1; i < cols; i++) {
                    row[i-1] = rs.getObject(i + 1);
                }
                model.addRow(row);
            }
            st.close();
            con.close();
        } catch (ClassNotFoundException | SQLException e1) {
            e1.printStackTrace();
        }*/
    	 try {
    	        Class.forName("com.mysql.jdbc.Driver");
    	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "");
    	        System.out.println("connected");

    	        java.sql.Statement st = con.createStatement();
    	        ResultSet rs = st.executeQuery("select * from postajob");

    	        DefaultTableModel model = new DefaultTableModel();
    	        tblData.setModel(model);

    	        // Add columns to the table model
    	        ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();
    	        int columnCount = metaData.getColumnCount();
    	        for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
    	            model.addColumn(metaData.getColumnLabel(columnIndex));
    	        }

    	        // Add rows to the table model
    	        while (rs.next()) {
    	            Object[] rowData = new Object[columnCount];
    	            for (int i = 0; i < columnCount; i++) {
    	                rowData[i] = rs.getObject(i + 1);
    	            }
    	            model.addRow(rowData);
    	        }

    	        st.close();
    	        con.close();
    	    } catch (ClassNotFoundException | SQLException e1) {
    	        e1.printStackTrace();
    	    }
    }
}

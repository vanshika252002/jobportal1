package guiapp;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class second extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txt1;
	private JTextField txt2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					second frame = new second();
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // This ensures the frame closes properly

					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public second() {
		setTitle("Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 733, 430);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(173, 216, 230));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel.setBounds(465, 20, 108, 41);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1.setBounds(459, 71, 85, 22);
		contentPane.add(lblNewLabel_1);
		
		txt1 = new JTextField();
		txt1.setBounds(458, 103, 192, 19);
		contentPane.add(txt1);
		txt1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(459, 145, 96, 22);
		contentPane.add(lblNewLabel_2);
		
		txt2 = new JTextField();
		txt2.setBounds(458, 177, 192, 19);
		contentPane.add(txt2);
		txt2.setColumns(10);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 10));
		/*btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				 try {
					int count=0;
					 String user=txt1.getText();
					 String password=txt2.getText();
						Class.forName("com.mysql.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/student","root","");
						System.out.print("connected");
						java.sql.Statement stmt=con.createStatement();  
						ResultSet rs=stmt.executeQuery("select * from login");  
						while(rs.next())
						{
						//System.out.println(rs.getString(1)+"  "+rs.getString(2));  
						 if( user.equals(rs.getString(1))&& password.equals(rs.getString(2)))
						 {
							 System.out.println("connection oriented");
							 count++;
					        
						 }
						 
						}
						if(count>0)
						{
							System.out.println("connection oriented");
						}
						else
						{
							System.out.println("not");
						}
						con.close(); 
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}  
				
			
				
				
			 }
				
			
		});*/
		btnNewButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        try {
		            String user = txt1.getText();
		            String password = txt2.getText();
		            Class.forName("com.mysql.cj.jdbc.Driver");
		            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "");
		            java.sql.Statement stmt = con.createStatement();
		            ResultSet rs = stmt.executeQuery("SELECT * FROM loginadmin WHERE username='" + user + "' AND password='" + password + "'");
		            
		            if (rs.next()) {
		                // If a match is found in loginadmin, open the admin frame
		                new admin().setVisible(true); 
		                return; // Exit method to prevent further checks
		            }
		            rs.close(); // Close the ResultSet
		            
		            
		            ResultSet rs1 = stmt.executeQuery("SELECT * FROM login WHERE username='" + user + "' AND password='" + password + "'");
		            if (rs1.next()) {
		                // If a match is found in login, open the user frame
		                new user().setVisible(true); 
		                return; // Exit method to prevent further checks
		            }
		            rs1.close(); // Close the ResultSet
		            
		            ResultSet rs2 = stmt.executeQuery("SELECT * FROM recruiter WHERE username='" + user + "' AND password='" + password + "'");
		            if (rs2.next()) {
		                // If a match is found in recruiter, open the recruiter frame
		                new recruiter().setVisible(true); 
		            } else {
		                // If no match is found in any table, display an error message
		                System.out.println("Invalid username or password");
		            }
		            
		            // Close resources
		            rs2.close();
		            stmt.close();
		            con.close();
		        } catch (ClassNotFoundException | SQLException e1) {
		            e1.printStackTrace();
		        }
		            
		            
		            
		            
		            
		            
		            
		        
		    }
		});
		
		
		
		
		
		
		//end
		btnNewButton.setBounds(450, 264, 188, 22);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("<");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new app().setVisible(true); 
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_1.setBounds(0, 0, 56, 31);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBackground(new Color(32, 178, 170));
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\vansh\\OneDrive\\Pictures\\Screenshots\\Screenshot (4).png"));
		lblNewLabel_3.setBounds(-568, -56, 933, 459);
		contentPane.add(lblNewLabel_3);
	}
}

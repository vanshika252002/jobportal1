package guiapp;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class admin extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					admin frame = new admin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public admin() {
		setTitle("ADMIN ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 928, 552);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.menu);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(-173, 38, 1125, 267);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\vansh\\Downloads\\WhatsApp Image 2024-03-03 at 9.46.19 PM.jpeg"));
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setForeground(Color.WHITE);
		panel.setBackground(Color.WHITE);
		panel.setBounds(66, 315, 269, 177);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\vansh\\Downloads\\WhatsApp Image 2024-03-03 at 9.55.41 PM.jpeg"));
		lblNewLabel_1.setBounds(54, -18, 147, 120);
		panel.add(lblNewLabel_1);
		
		JButton btnNewButton_2 = new JButton("Recruiter");
		btnNewButton_2.setBackground(SystemColor.textHighlight);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new noofrecruiters().setVisible(true); 
				
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		btnNewButton_2.setForeground(SystemColor.controlLtHighlight);
		btnNewButton_2.setBounds(54, 119, 171, 29);
		panel.add(btnNewButton_2);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(SystemColor.textHighlight);
		panel_1.setBounds(0, 0, 914, 40);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JButton btnNewButton = new JButton(" JOBS");
		btnNewButton.setBounds(675, 0, 109, 40);
		panel_1.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new postajob().setVisible(true); 
				
				
			}
		});
		btnNewButton.setBackground(SystemColor.textHighlight);
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton.setForeground(SystemColor.text);
		
		JButton btnNewButton_4 = new JButton("PREVIOUS JOBS");
		btnNewButton_4.setForeground(SystemColor.text);
		btnNewButton_4.setBackground(SystemColor.textHighlight);
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new demo().setVisible(true); 
			}
		});
		btnNewButton_4.setBounds(156, 0, 247, 40);
		panel_1.add(btnNewButton_4);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(SystemColor.text);
		panel_2.setBounds(518, 315, 279, 177);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\vansh\\Downloads\\WhatsApp Image 2024-03-03 at 9.55.41 PM.jpeg"));
		lblNewLabel_2.setBounds(59, -23, 167, 131);
		panel_2.add(lblNewLabel_2);
		
		JButton btnNewButton_3 = new JButton("User");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new adminseeuser().setVisible(true); 
			}
		});
		btnNewButton_3.setForeground(SystemColor.controlLtHighlight);
		btnNewButton_3.setBackground(SystemColor.textHighlight);
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 10));
		btnNewButton_3.setBounds(89, 118, 104, 21);
		panel_2.add(btnNewButton_3);
	}
}

package guiapp;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

import java.awt.Color;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class applyforajob extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	 private JTable tblData;
	 private JTextField l1;
	 private JButton btnNewButton_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					applyforajob frame = new applyforajob();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public applyforajob() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 879, 572);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 31, 835, 303);
		contentPane.add(scrollPane);
		
		tblData = new JTable();
		scrollPane.setViewportView(tblData);
		
		l1 = new JTextField();
		l1.setBounds(216, 410, 96, 19);
		contentPane.add(l1);
		l1.setColumns(10);
		
		
		//start
		
		
		
		
		
		
		
		//end
		JButton btnNewButton = new JButton("apply");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String textFromTextField = l1.getText(); // Get the text from the JTextField
				 boolean snoExists = checkSnoExists(textFromTextField);                                             //
				
				 if (snoExists) {
	            afterapplybutton frame2 = new afterapplybutton(); // Create an instance of the second JFrame
	            frame2.setVisible(true); // Make the second JFrame visible
	            frame2.setLabelText(textFromTextField); // Pass the text to the second JFrame
	           // JOptionPane.showMessageDialog(null, "Application submitted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
				
			}	else
			{
				JOptionPane.showMessageDialog(null, "Sno not found!", "Error", JOptionPane.ERROR_MESSAGE);
			}}
			 private boolean checkSnoExists(String sno) {
	                try {
	                    Class.forName("com.mysql.cj.jdbc.Driver");
	                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "");
	                    System.out.println("connected");

	                    PreparedStatement ps = con.prepareStatement("select * from postajob where sno = ?");
	                    ps.setString(1, sno);
	                    ResultSet rs = ps.executeQuery();

	                    boolean exists = rs.next(); // If there is at least one row, sno exists

	                    rs.close();
	                    ps.close();
	                    con.close();

	                    return exists;
	                } catch (ClassNotFoundException | SQLException e) {
	                    e.printStackTrace();
	                    return false;
	                }
	            }
	        });
			
			
			
			
			
			
	//end
		btnNewButton.setBounds(419, 409, 85, 21);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton(">");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new user().setVisible(true); 
			}
		});
		btnNewButton_1.setBounds(0, 0, 63, 21);
		contentPane.add(btnNewButton_1);
		  fetchDataFromDatabase();
	}
	private void fetchDataFromDatabase() {
	       
	    	 try {
	    	        Class.forName("com.mysql.jdbc.Driver");
	    	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "");
	    	        System.out.println("connected");

	    	        java.sql.Statement st = con.createStatement();
	    	        ResultSet rs = st.executeQuery("select * from postajob");

	    	        DefaultTableModel model = new DefaultTableModel();
	    	        tblData.setModel(model);

	    	        // Add columns to the table model
	    	        ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();
	    	        int columnCount = metaData.getColumnCount();
	    	        for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
	    	            model.addColumn(metaData.getColumnLabel(columnIndex));
	    	        }

	    	        // Add rows to the table model
	    	        while (rs.next()) {
	    	            Object[] rowData = new Object[columnCount];
	    	            for (int i = 0; i < columnCount; i++) {
	    	                rowData[i] = rs.getObject(i + 1);
	    	            }
	    	            model.addRow(rowData);
	    	        }

	    	        st.close();
	    	        con.close();
	    	    } catch (ClassNotFoundException | SQLException e1) {
	    	        e1.printStackTrace();
	    	    }
	    }
}
